#SXD20|20011|50505|50640|2019.02.13 14:56:41|maikoffN|0|0|0|
#PR ru_catalog_index_stack_update|ru_catalog_index_update_price|ru_print_index_stack_update
#FU ru_catalog_index_get_price
#EOH

#	PR`ru_catalog_index_stack_update`utf8_general_ci	;
CREATE PROCEDURE `ru_catalog_index_stack_update`(IN `entityID` INT(11), IN `entityType` varchar(255))
    NO SQL
BEGIN
                      INSERT INTO `ru_catalog_index_stack` (`entity_id`, `entity_type`) 
                        VALUES (entityID, entityType) 
                        ON DUPLICATE KEY UPDATE `applied`=0;
                    END	;
#	PR`ru_catalog_index_update_price`utf8_general_ci	;
CREATE PROCEDURE `ru_catalog_index_update_price`(IN eurRate VARCHAR(50), roundPrecision VARCHAR(50))
    NO SQL
BEGIN
                      DECLARE sUndefined VARCHAR(4) DEFAULT '-||-';
                      IF(eurRate != sUndefined || roundPrecision != sUndefined) THEN 
                        UPDATE `ru_catalog_index` 
                        SET `eur_rate`        = IF(eurRate=sUndefined, `eur_rate`, CAST(eurRate AS DECIMAL(8,2))), 
                            `round_precision` = IF(roundPrecision=sUndefined, `round_precision`, CAST(roundPrecision AS DECIMAL(2,0))), 
                            `product_price`   = `ru_catalog_index_get_price`(`eur_price`, IF(eurRate=sUndefined, `eur_rate`, eurRate), IF(roundPrecision=sUndefined, `round_precision`, roundPrecision))
                        ;
                      END IF;
                    END	;
#	PR`ru_print_index_stack_update`utf8_general_ci	;
CREATE PROCEDURE `ru_print_index_stack_update`(IN `entityID` INT(11), IN `entityType` varchar(255))
    NO SQL
BEGIN
                      INSERT INTO `ru_print_index_stack` (`entity_id`, `entity_type`) 
                        VALUES (entityID, entityType) 
                        ON DUPLICATE KEY UPDATE `applied`=0;
                    END	;
#	FU`ru_catalog_index_get_price`utf8_general_ci	;
CREATE FUNCTION `ru_catalog_index_get_price`(eurPrice FLOAT(8,2), eurRate VARCHAR(50), roundPrecision VARCHAR(50)) RETURNS float(11,2)
    DETERMINISTIC
BEGIN
                      DECLARE fPrice FLOAT(11,2) DEFAULT CAST(eurPrice AS DECIMAL(11,2));
                      DECLARE fRate FLOAT(8,2) DEFAULT CAST(eurRate AS DECIMAL(8,2));
                      DECLARE iPrecision TINYINT(2) DEFAULT CAST(roundPrecision AS DECIMAL(2,0));
                      IF (fPrice != 0) THEN
                        IF (fRate != 0) THEN
                          SET fPrice = fPrice*fRate;
                        END IF;
                        IF (iPrecision >= 0) THEN
                             SET fPrice = ROUND(fPrice, iPrecision);
                        END IF;
                      END IF;
                      RETURN fPrice;
                    END	;
